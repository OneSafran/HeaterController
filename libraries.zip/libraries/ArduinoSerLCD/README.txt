Arduino SerLCD Library by Steven Cogswell.  Works with 16x2 and 20x4 SerLCDs from Sparkfun.

I wrote this, originally posted with instructions on http://awtfy.com/2010/11/08/yet-another-sparkfun-serlcd-library-for-arduino/  

/******************************************************************************* 
SerLCD - A library to use Sparkfun's SerLCD v2.5 backpack devices with the Arduino
Copyright (C) 2010-2013 Steven Cogswell

http://www.sparkfun.com/commerce/product_info.php?products_id=258
http://www.sparkfun.com/commerce/product_info.php?products_id=9395
https://www.sparkfun.com/products/9568
http://www.sparkfun.com/datasheets/LCD/SerLCD_V2_5.PDF

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

	
***********************************************************************************/